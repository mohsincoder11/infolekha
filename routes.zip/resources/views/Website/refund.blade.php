@extends('website_layout')
@section('website_content')
 <!-- Page title -->
    <div class="page-title parallax parallax1">
        <div class="section-overlay">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">                    
                    <div class="page-title-heading">
                        <h1 class="title">Refund & Cancellation</h1>
                    </div><!-- /.page-title-captions -->
                    <div class="breadcrumbs">
                        <!-- <ul>
                            <li><a href="index.html"></a></li>
                          
                        </ul>                    -->
                    </div><!-- /.breadcrumbs -->   
                </div><!-- /.col-md-12 -->  
            </div><!-- /.row -->  
        </div><!-- /.container -->                      
    </div><!-- /.page-title -->

    <section class="flat-row section-about1 parallax parallax3" style="margin-bottom:5%;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-section text-center" style="margin-top: 7px;">
                        <h1 class="title"></h1>
                       
                    </div>
                </div>
            </div>
            <div class="row" >
				<div class="col-md-1"></div>
              <div class="col-md-10" style="padding-top:20px; padding-left:5%; padding-right:5%; padding-top:5%; padding-bottom:5%;
                            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
              <h6>No Refund</h6>

<p align="justify">We do not offer refunds for any services purchased through the website. Once a service is purchased, the user is responsible for paying for the service, even if they no longer want it or do not use it. INFOlekha provides digital products or services, such as Information, listing, Digital Advertisement or Marketing, digital downloads etc where there is no physical product to return. Hence its companies policy that there will be No refund provided once services are availed.
</p>








                </div>
              
            </div>
        </div>     
    </section> 
    <!-- Footer -->
@stop