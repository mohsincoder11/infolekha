@extends('website_layout')
@section('website_content')
  <img src="{{ asset('website_asset/images/bgg.jpg')}}">
@endsection
