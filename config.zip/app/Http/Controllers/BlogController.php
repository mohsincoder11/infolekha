<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Blog;

class BlogController extends Controller
{
    public function index(){

        $blogs=Blog::select('id','subject',
        'category',
        'user_id',
        'blog_image',
        'created_at',
 'status')->orderby('id','desc')->get();
        return view('add-blogs',['blogs'=>$blogs]);
    }

    public function create(Request $request){
        $validator = Validator::make(
            $request->all(),
            [
                'blog_image' => ['required'],
             'title'=>['required'],
             'author_name'=>['required'],
             'publish_date'=>['required'],
             'blogs'=>['required'],
                
            ],
            [
               
               'blog_image.required' => 'Please upload Blog Image.',
                'title.required' => 'Please enter Title.',
                'author_name.required' => 'Please enter Author Name.',
                'publish_date.required' => 'Please enter Publish Date.',
                'blogs.required' => 'Please enter Blogs.',
               
            ]);
            if ($validator->fails()) {
                $errors = '';
                $messages = $validator->messages();
                foreach ($messages->all() as $message) {
                    $errors .= $message . "<br>";
                }
                return back()->with(['error'=>$errors]);
            }

        $blogcreate=new Blog;

        $filename='';
        if($request->hasFile('blog_image')){
            $file= $request->file('blog_image');
            $filename=rand(0123,9999).time().'.'.$file->getClientOriginalExtension();
            $file->move(public_path('images/'), $filename);
            $blogcreate->blog_image= 'images/'.$filename;
    
        }
        // $blogcreate->blog_image=$request->get('blog_image');
        
        $blogcreate->title=$request->get('title');
        $blogcreate->author_name=$request->get('author_name');
        $blogcreate->publish_date=$request->get('publish_date');
        $blogcreate->blogs=$request->get('blogs');
        // $blogcreate->blog_editor=$request->get('blog_editor');
        $blogcreate->save();
        return redirect(route('admin.blog'))->with(['success'=>'Successfully Inserted.']);
    }

    public function get_blog(Request $request){
     $editblog = Blog::find($request->BlogID); 
     return response()->json($editblog);

    }

    public function edit($id)
 {
     $editblog = Blog::find($id); 
     $blogss = Blog::all();
     return view('editblog',['editblog'=>$editblog,'blogss'=>$blogss]);
 }

public function change_blog_status(Request $request){
    $validator = Validator::make(
        $request->all(),
        [
            'BlogID' => ['required'],
            'status' => ['required'],
        ]);

        if ($validator->fails()) {
            $errors = '';
            $messages = $validator->messages();
            foreach ($messages->all() as $message) {
                $errors .= $message . "<br>";
            }
            return back()->with(['error'=>$errors]);
        }

        $updateblog=Blog::find($request->BlogID);
        $updateblog->status=$request->status;
        $updateblog->category=$request->category;
        $updateblog->content1=$request->content1;
        $updateblog->content2=$request->content2;
        $updateblog->content3=$request->content3;
        $updateblog->content4=$request->content4;
        $updateblog->reject_reason=$request->note;
        $updateblog->save();
    return redirect(route('admin.blog'))->with(['success'=>'Status Successfully updated.']);

}
 public function update(Request $request)
 {
    

    $validator = Validator::make(
        $request->all(),
        [
            //'blog_image' => ['required'],
         'title'=>['required'],
         'author_name'=>['required'],
         'publish_date'=>['required'],
         'blogs'=>['required'],
            
        ],
        [
           
           // 'blog_image.required' => 'Please enter Blog Image.',
            'title.required' => 'Please enter Title.',
            'author_name.required' => 'Please enter Author Name.',
            'publish_date.required' => 'Please enter Publish Date.',
            'blogs.required' => 'Please enter Blogs.',
           
        ]);
        if ($validator->fails()) {
            $errors = '';
            $messages = $validator->messages();
            foreach ($messages->all() as $message) {
                $errors .= $message . "<br>";
            }
            return back()->with(['error'=>$errors]);
        }


    $updateblog=Blog::find($request->id);
    if($request->hasFile('blog_image')){
        $file= $request->file('blog_image');
        $filename=rand(0123,9999).time().'.'.$file->getClientOriginalExtension();
        $file->move(public_path('images/'), $filename);
        $updateblog->blog_image= 'images/'.$filename;

    }
    $updateblog->title=$request->get('title');
        $updateblog->author_name=$request->get('author_name');
        $updateblog->publish_date=$request->get('publish_date');
        $updateblog->blogs=$request->get('blogs');
    // $updateblog->blogs=$request->get('blogs');
    $updateblog->save();
    // return redirect(route('admin.blog')); 
     return redirect()->route('admin.blog')->with(['success'=>'Successfully Updated !']);
   
 }

 public function destroy($id)
 {
     $blogdelete=Blog::where('id',$id)->delete();
     return redirect(route('admin.blog'))->with(['success'=>'Blog deleted successfully !']);;
 }

}

